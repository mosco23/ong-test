<div class="grid grid-cols-1 gap-y-3"   x-data="{'isModalOpen': false}" x-on:keydown.escape="isModalOpen=false">
    <div>
        <span class="p-2 border-b-2 border-r-2 border-green-600 text-slate-600 font-semibold rounded-r-xl">
            
            <?php echo e($activity->getDate()); ?> <?php if($activity->start_at): ?> De <?php endif; ?> <?php echo e(!$activity->start_at ? '' : $activity->getTime($activity->start_at)); ?> <?php if($activity->end_at): ?> &agrave; <?php endif; ?> <?php echo e(!$activity->end_at ? '' : $activity->getTime($activity->end_at)); ?>

            
        </span>
    </div>
    <div class="flex flex-col justify-between">
        <div class="text-slate-600 text-justify">
            <?php echo e($activity->name); ?>

        </div>
        <div class="p-5 h-max group/img relative">
            <div class="relative h-72">
                <?php $__currentLoopData = $activity->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    <img src="<?php echo e($img->getImageResized('sm')); ?>" alt=""
                        class="absolute shadow w-96 h-64 last:transform last:-rotate-6 wow wobble"
                        data-wow-delay="<?php echo e($key); ?>s"
                        data-wow-duration="2s"
                        >
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo $__env->make('items.modal', ['images' => $activity->images ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            
            
        </div>
    </div>
</div><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/items/activity-card.blade.php ENDPATH**/ ?>