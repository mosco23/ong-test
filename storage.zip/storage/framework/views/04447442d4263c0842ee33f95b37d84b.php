<div class="my-8 grid grid-cols-1 gap-y-5 px-2">
    <h1 class="text-pink-600 font-bold text-xl md:text-3xl lg:text-4xl text-center capitalize wow fadeInUp mb-3"
    data-wow-duration="2s" data-wow-delay="0.3s"><?php echo e($title); ?></h1>
    <h2 class="text-blue-600 text-6xl font-bold text-center capitalize wow fadeInUp" 
        data-wow-duration="2s" data-wow-delay="0.5s">
        <?php echo e($subTitle); ?>

    </h2>
</div><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/items/section-title.blade.php ENDPATH**/ ?>