<div class="flex flex-col space-y-3">
    <h1 class="text-white font-bold text-2xl">Liens Rapides</h1>
    <ul class="list-disc grid grid-cols-1 gap-y-3 text-white font-bold text-sm">
        <?php $__currentLoopData = $navitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e($item->link); ?>"><?php echo e($item->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </ul>
</div><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/components/navbar-bottom.blade.php ENDPATH**/ ?>