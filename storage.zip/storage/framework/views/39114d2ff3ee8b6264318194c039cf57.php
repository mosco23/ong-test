<h2 class="text-blue-600 text-xl md:text-3xl lg:text-4xl font-bold text-center capitalize wow fadeInUp" 
    data-wow-duration="2s" data-wow-delay="0.5s">
    <?php echo e($title); ?>

</h2><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/items/section-title-2.blade.php ENDPATH**/ ?>