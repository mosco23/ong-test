<?php
    $img_list = ['logo.png', 'scolarisation.webp', 'vbg.webp'];
    $img = 'logo.png';
?>

<section>
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-1 gap-y-4 lg:w-1/2 mx-auto p-5">
        <?php $__currentLoopData = range(0, 13); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-contain bg-no-repeat bg-center h-52" style="background-image: url('/img/<?php echo e($img); ?>')">
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/sections/partners.blade.php ENDPATH**/ ?>