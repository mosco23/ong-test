<div class="hover:shadow-lg px-8 py-12 bg-white grid grid-cols-1 gap-y-5 ">
    <div class="flex items-center justify-center">
        <div class="circular">
            <div class="inner">
                <div class="circle">
                    <div class="bar left border-4 <?php echo e($color); ?>">
                        <div class="progress"></div>
                    </div>
                    <div class="m-5 absolute top-auto left-auto">
                        <?php echo $__env->make("svg/".$svg, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="bar right border-4 <?php echo e($color); ?>">
                        <div class="progress"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-5xl font-bold text-slate-600 text-center"
        x-data="clock"
        x-init="max = 200; init()"
        x-text="counter"></div>
    <p class="text-center text-slate-500">Description</p>
</div>


 
<?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/items/stat-card.blade.php ENDPATH**/ ?>