    <!-- #### Area Content ###-->
    <?php $__env->startSection('contenu'); ?>
        <?php $__currentLoopData = $tabSection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($var = 'data' . ucfirst($sect['vue'])); ?>
            <?php ($$var = $data[$sect['vue']] ?? []); ?>
            <?php ($donnees = $sect['items']); ?>
            <?php echo $__env->make("sections.$sect[vue]", compact($var, 'donnees', 'page'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.$template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/page.blade.php ENDPATH**/ ?>