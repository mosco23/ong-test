<section class="h-full">
   <div>
    <img src="/img/principale.jpg" alt="" 
        class="w-fit">
   </div>
</section><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/sections/first.blade.php ENDPATH**/ ?>