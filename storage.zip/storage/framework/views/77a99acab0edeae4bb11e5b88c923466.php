<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/app.css">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link rel="stylesheet" href="/css/animate.css">
    <link rel="stylesheet" href="/css/style.css">
    <script src="/js/orgchart.default.js"></script>
    
    <title><?php echo e(env('APP_NAME')); ?></title>
</head>
<body x-data="{ atTop: false }">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="grid grid-cols-1 bg-slate-200 ">
        <?php echo $__env->yieldContent('sidebar'); ?>
        <?php echo $__env->yieldContent('contenu'); ?>
    </main>
    <!-- Importation CDN wow.min.js -->
	
    <script src="/js/wow.min.js"></script>
    <script src="/js/alpine_data.js"></script>
    
    <script>
        new WOW().init();
    </script>
</body>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/layouts/master.blade.php ENDPATH**/ ?>