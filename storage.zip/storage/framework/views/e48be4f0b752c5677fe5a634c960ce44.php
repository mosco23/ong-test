<?php
    $img_list = ['bg-pink-600' => '/img/fondatrice.webp', 'bg-purple-600' => '/img/coordonnateur.webp', 'bg-teal-600' => '/img/vice_president.webp']
?>
<section>
    <?php echo $__env->make('items.section-title', ['title' => 'Equipe', 'subTitle' => 'Notre Equipe' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-y-10 md:gap-y-0 lg:gap-x-5 md:px-5 lg:w-3/4 mx-auto">
        <?php $__currentLoopData = $img_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <?php echo $__env->make('items.team-card', ['img' => $item, 'color' => $key], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/sections/team.blade.php ENDPATH**/ ?>