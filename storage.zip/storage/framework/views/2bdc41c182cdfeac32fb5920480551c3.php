<iframe src="/pdf/ONG ASE2D_PV 01_04112021.pdf"
    frameborder="0"
    class="w-full h-96"></iframe><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/items/pdf-view.blade.php ENDPATH**/ ?>