<div class="mx-3 md:mx-0 scaler w-full aspect-video">
    
    <div class="w-full scaler-child">
        <img src="/storage/<?php echo e($img->url); ?>" alt="" class="object-cover w-full">
    </div>
    
</div><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/items/event-card.blade.php ENDPATH**/ ?>