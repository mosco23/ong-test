<div class="grid grid-cols-1 divide-y"
    x-data="{
        index:0,
        setIndex(i){
            if(i === this.index){
                this.index = 0;
            }else{
                this.index = i;
            }
        }
    }">
    <?php $__currentLoopData = $navitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="">
            <?php
                $activated = false;
                if(request()->segment(1) ==$navitem->link || $navitem->items->where('link', request()->segment(1))->isNotEmpty()){
                    $activated = true;
                }
            ?>
            <div class="flex justify-between items-center cursor-pointer p-1" 
                x-transition:enter.duration.500ms
                x-transition:leave.duration.400ms>
                <?php if($navitem->link == '#'): ?>
                    <div class="<?php echo e($activated ? 'text-pink-500' : 'hover:text-pink-600'); ?> w-full h-full p-3">
                        <?php echo e($navitem->name); ?>

                    </div>
                <?php else: ?>
                    <div class="p-3">
                        <a href="/<?php echo e($navitem->link); ?>" class="p-3 hover:text-white hover:bg-pink-600 min-w-max <?php echo e(!($activated && $navitem->items->isEmpty()) ? 'text-slate-600' : 'text-white bg-pink-600'); ?>"><?php echo e($navitem->name); ?></a>
                    </div>
                <?php endif; ?>
                <?php if($navitem->items->isNotEmpty()): ?>
                    <div class="border-l p-3" @click="setIndex(<?php echo e($navitem->id); ?>)">
                        <span x-show="!(index === <?php echo e($navitem->id); ?>)">
                            <?php echo $__env->make('svg.plus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </span>
                        <span x-show="(index === <?php echo e($navitem->id); ?>)">
                            <?php echo $__env->make('svg.minus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                    </div>
                <?php endif; ?>
            </div>
            <div class="grid grid-cols-1 divide-y" x-show="index === <?php echo e($navitem->id); ?>">
                <?php $__currentLoopData = $navitem->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $activated = false;
                        if(request()->segment(1) ==$sub->link){
                            $activated = true;
                        }
                    ?>
                    <a href="/<?php echo e($sub->link); ?>" class="h-fit w-full p-3 first:border-t hover:text-white hover:bg-pink-600 min-w-max <?php echo e(!$activated ? 'text-slate-600' : 'text-white bg-pink-600'); ?>"><?php echo e($sub->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/items/mobile-navbar.blade.php ENDPATH**/ ?>