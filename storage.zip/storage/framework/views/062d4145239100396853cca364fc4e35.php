<section class="py-12">
    <div></div>
</section><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/sections/activity-repport.blade.php ENDPATH**/ ?>