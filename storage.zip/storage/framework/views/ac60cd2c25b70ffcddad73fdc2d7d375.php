<?php
    $list = ['border-amber-500' => 'star', 'border-pink-500' => 'book', 'border-purple-500' => 'building', 'border-green-500' => 'hand'];
?>

<section class="py-14">
    <?php echo $__env->make('items.section-title', ['title' => 'en chiffre', 'subTitle' => 'OING ASE2D' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-y-5 md:gap-x-5 md:w-5/6 lg:w-2/3 mx-auto y-10">
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('items.stat-card', ['svg' => $item, 'color' => $color], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/sections/stat.blade.php ENDPATH**/ ?>