<section class="bg-white py-14">
    <div class="w-full h-full p-2">
        <div id="tree"></div>
    </div>

    <script src="/js/orgchart.js"></script>
</section><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/sections/team-2.blade.php ENDPATH**/ ?>