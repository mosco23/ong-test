<div class="ml-4 flex flex-col justify-between space-y-3 h-full text-justify ">
    <div class="border-b-4 border-blue-600 py-3 text-center font-semibold"><?php echo e($pv->getDate()); ?></div>
    <h3 class="text-slate-600 font-semibold text-xl"><?php echo e($pv->name); ?></h3>
    <div class="text-justify grid grid-cols-1 gap-y-2">
        <ul class="list-decimal grid grid-cols-1 gap-y-2">
            <?php $__currentLoopData = $pv->agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($agenda->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <p>Divers</p>
    </div>
    <div class="flex justify-end pr-5">
        <?php echo $__env->make('items.pdf-viewer-modal', ['pdf' => $pv->url], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/items/pv-card.blade.php ENDPATH**/ ?>