<?php
    $img_list = ['/img/prix.webp', '/img/scolarisation.webp', '/img/vbg.webp']
?>
<section class="py-10 bg-white">
    <?php echo $__env->make('items.section-title', ['title' => 'missions', 'subTitle' => 'Nos missions' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-y-8 lg::gap-x-5 md:w-5/6 lg:w-2/3 mx-auto">
        <?php $__currentLoopData = $img_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('items.mission-card', ['img' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/sections/missions-overview.blade.php ENDPATH**/ ?>