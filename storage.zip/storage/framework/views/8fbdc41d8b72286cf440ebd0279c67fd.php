<section class="py-14 bg-white">
    <div class="md:w-3/4 mx-2 md:mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 md:gap-3 lg:gap-5"
    >
        <?php $__currentLoopData = \App\Models\Activity::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('items.activity-card', ["key" => $key, 'activity' => $activity], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    
</section>
<?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/sections/activity.blade.php ENDPATH**/ ?>