<ul class="h-full items-center justify-evenly
    font-medium rounded-lg"
    :class="window.innerWidth < 945 ? 'hidden' : 'flex'"
    >
    <?php $__currentLoopData = $navitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class=" relative group/item" x-data="{open: false}">
            <?php
                $activated = false;
                if(request()->segment(1) ==$navitem->link || $navitem->items->where('link', request()->segment(1))->isNotEmpty()){
                    $activated = true;
                }
            ?>
            <a href="<?php echo e($navitem->link); ?>" class="py-7 pl-3 pr-4 font-bold capitalize
                 flex items-center space-x-2
                 <?php echo e($activated ? 'text-pink-500' : 'group-hover/item:text-pink-600'); ?>" 
                 :class="fontSize()"
                 aria-current="page">
                <span><?php echo e($navitem->name); ?></span>
                <?php if($navitem->items->isNotEmpty()): ?>
                    <span class="h-4"><?php echo $__env->make('svg.arrow-down', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                <?php endif; ?>
            </a>
            <?php if($navitem->items->isNotEmpty()): ?>
                <div class="absolute top-[80%] min-w-max hidden group-hover/item:grid grid-cols-1 group-hover/item:transition duration-300 divide-y-2 bg-white text-slate-600 font-semibold uppercase"
                    x-transition.duration.500ms>
                    <?php $__currentLoopData = $navitem->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $activated = false;
                            if(request()->segment(1) ==$sub->link){
                                $activated = true;
                            }
                        ?>
                        <a href="/<?php echo e($sub->link); ?>" class="h-fit p-3 w-full hover:text-white hover:bg-pink-600 <?php echo e(!$activated ? 'text-slate-600' : 'text-white bg-pink-600'); ?>"><?php echo e($sub->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/items/desktop-navbar.blade.php ENDPATH**/ ?>