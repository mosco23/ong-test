<?php $__env->startSection('sidebar'); ?>

<?php if (isset($component)) { $__componentOriginalb7a738f12aab0603f1717e0f1e793a52 = $component; } ?>
<?php $component = App\View\Components\SubNavbar::resolve(['link' => request()->segment(1)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sub-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SubNavbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7a738f12aab0603f1717e0f1e793a52)): ?>
<?php $component = $__componentOriginalb7a738f12aab0603f1717e0f1e793a52; ?>
<?php unset($__componentOriginalb7a738f12aab0603f1717e0f1e793a52); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/layouts/base.blade.php ENDPATH**/ ?>