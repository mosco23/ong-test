<?php
    $images = \App\Models\Image::pluck('url')
?>
<section class="py-14">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-y-3 md:gap-x-2 px-2 lg:w-3/5 md:px-5 lg:mx-auto">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <img src="/storage/<?php echo e($img); ?>" alt="" class="h-72 w-full">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section><?php /**PATH /home/mosco/projets/php_folder/laravel/ong-ase2d/resources/views/sections/mediatheque.blade.php ENDPATH**/ ?>